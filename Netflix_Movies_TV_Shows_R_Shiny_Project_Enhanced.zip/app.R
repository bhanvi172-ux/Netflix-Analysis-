# Netflix Movies & TV Shows Analysis - Interactive R Shiny Mini Project
# Run: shiny::runApp()

required_packages <- c("shiny", "shinydashboard", "dplyr", "ggplot2",
                       "plotly", "DT", "readr", "lubridate")
missing <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing) > 0) {
  stop(paste(
    "Please install the missing packages first:",
    paste(missing, collapse = ", "),
    "\nRun: install.packages(c(",
    paste(sprintf('"%s"', missing), collapse = ", "),
    "))"
  ))
}

library(shiny)
library(shinydashboard)
library(dplyr)
library(ggplot2)
library(plotly)
library(DT)
library(readr)
library(lubridate)

# A small demo dataset is included so the app works immediately.
# Upload the full Netflix titles CSV (commonly named netflix_titles.csv)
# from Kaggle / another permitted source for a larger analysis.
demo_data <- tibble::tribble(
  ~show_id, ~type, ~title, ~director, ~country, ~date_added, ~release_year, ~rating, ~duration, ~listed_in,
  "s1","Movie","The Last Summer","William Bindley","United States","August 3, 2019",2019,"TV-14","109 min","Comedies, Dramas, Romantic Movies",
  "s2","TV Show","Stranger Things","The Duffer Brothers","United States","July 4, 2019",2016,"TV-14","4 Seasons","TV Dramas, TV Horror, TV Sci-Fi & Fantasy",
  "s3","Movie","The Social Dilemma","Jeff Orlowski","United States","September 9, 2020",2020,"PG-13","94 min","Documentaries",
  "s4","TV Show","The Crown","Peter Morgan","United Kingdom","November 15, 2020",2016,"TV-MA","6 Seasons","British TV Shows, TV Dramas",
  "s5","Movie","Extraction","Sam Hargrave","United States","April 24, 2020",2020,"R","117 min","Action & Adventure",
  "s6","Movie","Dangal","Nitesh Tiwari","India","May 21, 2017",2016,"TV-14","161 min","International Movies, Dramas, Sports Movies",
  "s7","TV Show","Delhi Crime","Richie Mehta","India","March 22, 2019",2019,"TV-MA","2 Seasons","Crime TV Shows, International TV Shows",
  "s8","Movie","Enola Holmes","Harry Bradbeer","United Kingdom","September 23, 2020",2020,"PG-13","123 min","Action & Adventure",
  "s9","TV Show","Money Heist","Alex Pina","Spain","April 3, 2020",2017,"TV-MA","5 Seasons","Crime TV Shows, International TV Shows",
  "s10","Movie","The Great Hack","Jehane Noujaim","United States","July 24, 2019",2019,"TV-MA","114 min","Documentaries",
  "s11","Movie","Klaus","Sergio Pablos","Spain","November 15, 2019",2019,"PG","97 min","Children & Family Movies",
  "s12","TV Show","Our Planet","Alastair Fothergill","United Kingdom","April 5, 2019",2019,"TV-G","1 Season","Docuseries, Science & Nature TV",
  "s13","Movie","The Irishman","Martin Scorsese","United States","November 27, 2019",2019,"R","209 min","Dramas, Crime Movies",
  "s14","TV Show","Sacred Games","Anurag Kashyap","India","August 15, 2019",2018,"TV-MA","2 Seasons","Crime TV Shows, TV Dramas",
  "s15","Movie","Roma","Alfonso Cuaron","Mexico","December 14, 2018",2018,"R","135 min","Dramas, International Movies",
  "s16","TV Show","Dark","Baran bo Odar","Germany","June 21, 2019",2017,"TV-MA","3 Seasons","International TV Shows, TV Sci-Fi & Fantasy",
  "s17","Movie","To All the Boys I've Loved Before","Susan Johnson","United States","August 17, 2018",2018,"TV-14","99 min","Romantic Movies, Comedies",
  "s18","Movie","The White Tiger","Ramin Bahrani","India","January 22, 2021",2021,"R","125 min","Dramas, International Movies",
  "s19","TV Show","Bridgerton","Chris Van Dusen","United States","December 25, 2020",2020,"TV-MA","4 Seasons","Romantic TV Shows, TV Dramas",
  "s20","Movie","Train to Busan","Yeon Sang-ho","South Korea","October 1, 2017",2016,"TV-MA","118 min","Horror Movies, International Movies",
  "s21","Movie","The Mitchells vs. The Machines","Mike Rianda","United States","April 30, 2021",2021,"PG","114 min","Children & Family Movies, Comedies",
  "s22","TV Show","Lupin","George Kay","France","January 8, 2021",2021,"TV-MA","2 Parts","Crime TV Shows, International TV Shows",
  "s23","Movie","The Platform","Galder Gaztelu-Urrutia","Spain","March 20, 2020",2019,"TV-MA","95 min","International Movies, Sci-Fi & Fantasy",
  "s24","TV Show","The Queen's Gambit","Scott Frank","United States","October 23, 2020",2020,"TV-MA","1 Season","TV Dramas",
  "s25","Movie","A Silent Voice","Naoko Yamada","Japan","June 5, 2019",2016,"TV-14","130 min","Anime Features, International Movies",
  "s26","Movie","Mission Majnu","Shantanu Bagchi","India","January 20, 2023",2023,"TV-14","130 min","Action & Adventure, International Movies",
  "s27","TV Show","Wednesday","Tim Burton","United States","November 23, 2022",2022,"TV-14","1 Season","TV Comedies, TV Mysteries",
  "s28","Movie","Glass Onion","Rian Johnson","United States","December 23, 2022",2022,"PG-13","140 min","Comedies, Dramas",
  "s29","TV Show","The Sandman","Allan Heinberg","United States","August 5, 2022",2022,"TV-MA","1 Season","TV Dramas, TV Sci-Fi & Fantasy",
  "s30","Movie","RRR","S. S. Rajamouli","India","May 20, 2022",2022,"TV-14","187 min","Action & Adventure, International Movies"
)

normalise_data <- function(df) {
  required <- c("type", "title", "release_year")
  missing_cols <- setdiff(required, names(df))
  if (length(missing_cols)) stop(paste("CSV is missing required columns:", paste(missing_cols, collapse = ", ")))

  defaults <- list(show_id = NA_character_, director = "Not available",
                   country = "Not available", date_added = NA_character_,
                   rating = "Not rated", duration = NA_character_,
                   listed_in = "Uncategorised", description = "")
  for (nm in names(defaults)) if (!nm %in% names(df)) df[[nm]] <- defaults[[nm]]

  df %>%
    mutate(
      type = ifelse(is.na(type) | type == "", "Unknown", as.character(type)),
      title = ifelse(is.na(title) | title == "", "Untitled", as.character(title)),
      release_year = suppressWarnings(as.integer(release_year)),
      country = ifelse(is.na(country) | country == "", "Not available", as.character(country)),
      rating = ifelse(is.na(rating) | rating == "", "Not rated", as.character(rating)),
      listed_in = ifelse(is.na(listed_in) | listed_in == "", "Uncategorised", as.character(listed_in)),
      date_added_parsed = suppressWarnings(parse_date_time(date_added,
        orders = c("B d, Y", "b d, Y", "Y-m-d", "m/d/Y"))),
      added_year = year(date_added_parsed),
      duration_number = suppressWarnings(as.numeric(gsub("[^0-9.]", "", duration))),
      duration_unit = case_when(
        grepl("Season|Part", duration, ignore.case = TRUE) ~ "Seasons / Parts",
        grepl("min", duration, ignore.case = TRUE) ~ "Minutes",
        TRUE ~ "Unknown"
      )
    )
}

ui <- dashboardPage(
  skin = "black",
  dashboardHeader(title = "Netflix Content Explorer", titleWidth = 310),
  dashboardSidebar(
    width = 310,
    sidebarMenu(
      menuItem("Overview", tabName = "overview", icon = icon("dashboard")),
      menuItem("Content Analysis", tabName = "content", icon = icon("chart-bar")),
      menuItem("Explore Titles", tabName = "titles", icon = icon("film")),
      menuItem("About Project", tabName = "about", icon = icon("info-circle"))
    ),
    br(),
    fileInput("file", "Upload Netflix CSV", accept = c(".csv")),
    helpText("Expected columns include type, title and release_year. The standard Netflix titles dataset is supported."),
    selectInput("type_filter", "Content type", choices = c("All", "Movie", "TV Show"), selected = "All"),
    selectInput("country_filter", "Country", choices = "All", selected = "All"),
    sliderInput("year_filter", "Release year range", min = 1925, max = 2025, value = c(2000, 2025), sep = ""),
    actionButton("reset", "Reset filters", icon = icon("refresh"), width = "100%")
  ),
  dashboardBody(
    tags$head(
      tags$meta(name = "viewport", content = "width=device-width, initial-scale=1"),
      tags$style(HTML("
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
        body, h1, h2, h3, h4, p, button, input, select { font-family: 'Inter', 'Helvetica Neue', Arial, sans-serif; }
        body { background: #101014; }
        .content-wrapper, .right-side { background: #101014; }
        .main-header .logo { background: #09090b !important; color: #e50914 !important; font-size: 19px; font-weight: 800; letter-spacing: .4px; }
        .skin-black .main-header .navbar { background: #09090b !important; }
        .skin-black .main-header .navbar .sidebar-toggle:hover { background: #24242b; }
        .main-sidebar, .left-side { background: #15151b !important; }
        .sidebar-menu > li > a { color: #c7c7d1 !important; padding: 14px 16px; font-weight: 600; }
        .sidebar-menu > li.active > a, .sidebar-menu > li:hover > a { background: #292027 !important; border-left: 4px solid #e50914 !important; color: #fff !important; }
        .content { padding: 22px 24px; }
        .content-header { display: none; }
        .hero-panel { background: linear-gradient(115deg, #2a0b10 0%, #17171f 55%, #24242c 100%); border: 1px solid #3a242a; border-radius: 15px; padding: 26px 30px; margin-bottom: 22px; color: #fff; box-shadow: 0 12px 30px rgba(0,0,0,.22); }
        .hero-kicker { color: #ff7b82; text-transform: uppercase; letter-spacing: 2px; font-size: 11px; font-weight: 800; margin-bottom: 8px; }
        .hero-title { font-size: 27px; line-height: 1.2; font-weight: 800; margin: 0 0 8px 0; }
        .hero-subtitle { color: #c7c3ca; font-size: 13px; margin: 0; }
        .hero-mark { float: right; color: #e50914; font-size: 50px; font-weight: 900; line-height: 1; padding: 5px 12px; }
        .small-box { border-radius: 13px; overflow: hidden; box-shadow: 0 8px 22px rgba(0,0,0,.22); min-height: 112px; }
        .small-box h3 { font-size: 29px; font-weight: 800; }
        .small-box p { font-size: 12px; text-transform: uppercase; letter-spacing: 1px; font-weight: 700; }
        .box { background: #1b1b23; border: 1px solid #2c2c36; border-top: 0; border-radius: 13px; box-shadow: 0 8px 24px rgba(0,0,0,.18); }
        .box.box-solid.box-danger > .box-header { background: #1b1b23; color: #fff; border-bottom: 1px solid #30303a; border-radius: 13px 13px 0 0; padding: 15px 18px; }
        .box-title { font-size: 13px !important; font-weight: 700 !important; }
        .box-body { color: #e8e8ee; padding: 18px; }
        .box-body p, .box-body li { color: #c7c7d1; }
        .form-control, .selectize-input, .selectize-control.single .selectize-input { background: #24242d !important; color: #f5f5f7 !important; border: 1px solid #41414c !important; border-radius: 8px !important; }
        label { color: #dedee5; font-weight: 600; font-size: 12px; }
        .help-block { color: #a6a6b1; }
        .btn, .action-button { border-radius: 8px !important; font-weight: 700 !important; }
        .btn-default { background: #303039; color: #fff; border: 1px solid #454550; }
        .btn-default:hover { background: #e50914; color: #fff; border-color: #e50914; }
        table.dataTable { color: #e8e8ee !important; }
        table.dataTable thead th { background: #292932; color: #fff; border-bottom: 1px solid #444 !important; }
        table.dataTable tbody tr { background: #1e1e26 !important; }
        table.dataTable tbody tr:nth-child(even) { background: #24242d !important; }
        .dataTables_wrapper .dataTables_paginate .paginate_button { color: #fff !important; }
        .irs--shiny .irs-bar, .irs--shiny .irs-handle { background: #e50914; border-color: #e50914; }
        .sidebar .shiny-input-container { padding-left: 14px; padding-right: 14px; }
        .sidebar .control-label { color: #eee; }
        .sidebar .btn { margin: 8px 14px; width: calc(100% - 28px); }
        @media (max-width: 767px) { .content { padding: 12px; } .hero-panel { padding: 20px; } .hero-title { font-size: 22px; } .hero-mark { font-size: 36px; } }
      "))
    ),
    tabItems(
      tabItem(tabName = "overview",
        fluidRow(
          box(width = 12, status = NULL, solidHeader = FALSE,
              div(class = "hero-panel",
                  div(class = "hero-mark", "N"),
                  div(class = "hero-kicker", "Streaming catalogue intelligence"),
                  div(class = "hero-title", "Netflix Content Explorer"),
                  p(class = "hero-subtitle", "Discover catalogue trends, compare content types and explore titles through an interactive analytics dashboard.")
              )
          )
        ),
        fluidRow(
          valueBoxOutput("total_titles", width = 3),
          valueBoxOutput("movies", width = 3),
          valueBoxOutput("tvshows", width = 3),
          valueBoxOutput("countries", width = 3)
        ),
        fluidRow(
          box(title = "Movies vs TV Shows", status = "danger", solidHeader = TRUE, width = 6,
              plotlyOutput("type_chart", height = 300)),
          box(title = "Titles by Release Year", status = "danger", solidHeader = TRUE, width = 6,
              plotlyOutput("year_chart", height = 300))
        ),
        fluidRow(
          box(title = "Top 10 Content-Producing Countries", status = "danger", solidHeader = TRUE, width = 6,
              plotlyOutput("country_chart", height = 320)),
          box(title = "Content Ratings", status = "danger", solidHeader = TRUE, width = 6,
              plotlyOutput("rating_chart", height = 320))
        )
      ),
      tabItem(tabName = "content",
        fluidRow(
          box(title = "Most Common Genres / Categories", status = "danger", solidHeader = TRUE, width = 7,
              plotlyOutput("genre_chart", height = 380)),
          box(title = "Movie Duration Distribution", status = "danger", solidHeader = TRUE, width = 5,
              plotlyOutput("duration_chart", height = 380))
        ),
        fluidRow(
          box(title = "Content Added to Netflix by Year", status = "danger", solidHeader = TRUE, width = 12,
              plotlyOutput("added_chart", height = 300))
        )
      ),
      tabItem(tabName = "titles",
        fluidRow(
          box(title = "Search and Explore Titles", status = "danger", solidHeader = TRUE, width = 12,
              textInput("search_title", "Search by title, director, country or genre", ""),
              DTOutput("titles_table"),
              br(),
              downloadButton("download_data", "Download filtered data"))
        )
      ),
      tabItem(tabName = "about",
        fluidRow(box(width = 12, title = "Project Information", status = "danger", solidHeader = TRUE,
          h2("Netflix Movies and TV Shows Analysis"),
          p("An interactive data analytics mini project developed using R and Shiny."),
          h4("Objectives"),
          tags$ul(
            tags$li("Compare the number of Movies and TV Shows."),
            tags$li("Study content distribution across countries and release years."),
            tags$li("Explore ratings, genres and movie durations."),
            tags$li("Search, filter and download title records.")
          ),
          h4("Tools and Packages"),
          p("R, Shiny, shinydashboard, dplyr, ggplot2, plotly, DT, readr and lubridate."),
          h4("Dataset note"),
          p("The app starts with a small demonstration dataset. For meaningful full-scale results, download a Netflix titles CSV from a reputable public dataset provider and upload it using the sidebar. Check the dataset licence and cite its source in your report."),
          h4("How to run"),
          tags$pre("install.packages(c('shiny','shinydashboard','dplyr','ggplot2','plotly','DT','readr','lubridate','tibble'))\nshiny::runApp()")
        ))
      )
    )
  )
)

server <- function(input, output, session) {
  raw_data <- reactive({
    if (is.null(input$file)) demo_data else {
      tryCatch(read_csv(input$file$datapath, show_col_types = FALSE), error = function(e) {
        showNotification(paste("Could not read CSV:", e$message), type = "error")
        demo_data
      })
    }
  })

  data <- reactive({ normalise_data(raw_data()) })

  observeEvent(data(), {
    d <- data()
    countries <- sort(unique(d$country))
    updateSelectInput(session, "country_filter", choices = c("All", countries), selected = "All")
    yrs <- d$release_year[!is.na(d$release_year)]
    if (length(yrs)) {
      updateSliderInput(session, "year_filter",
        min = min(yrs), max = max(yrs),
        value = c(min(yrs), max(yrs)))
    }
  }, ignoreInit = FALSE)

  observeEvent(input$reset, {
    d <- data()
    updateSelectInput(session, "type_filter", selected = "All")
    updateSelectInput(session, "country_filter", selected = "All")
    yrs <- d$release_year[!is.na(d$release_year)]
    if (length(yrs)) updateSliderInput(session, "year_filter", value = c(min(yrs), max(yrs)))
    updateTextInput(session, "search_title", value = "")
  })

  filtered <- reactive({
    d <- data()
    if (input$type_filter != "All") d <- d %>% filter(type == input$type_filter)
    if (input$country_filter != "All") d <- d %>% filter(country == input$country_filter)
    if (length(input$year_filter) == 2) {
      d <- d %>% filter(is.na(release_year) | between(release_year, input$year_filter[1], input$year_filter[2]))
    }
    d
  })

  output$total_titles <- renderValueBox({
    valueBox(nrow(filtered()), "Total Titles", icon = icon("film"), color = "red")
  })
  output$movies <- renderValueBox({
    valueBox(sum(filtered()$type == "Movie", na.rm = TRUE), "Movies", icon = icon("video"), color = "maroon")
  })
  output$tvshows <- renderValueBox({
    valueBox(sum(filtered()$type == "TV Show", na.rm = TRUE), "TV Shows", icon = icon("tv"), color = "purple")
  })
  output$countries <- renderValueBox({
    valueBox(n_distinct(filtered()$country[filtered()$country != "Not available"]), "Countries", icon = icon("globe"), color = "blue")
  })

  output$type_chart <- renderPlotly({
    p <- filtered() %>% count(type) %>%
      ggplot(aes(x = type, y = n, fill = type, text = paste(type, n))) +
      geom_col(show.legend = FALSE) + labs(x = NULL, y = "Number of titles") +
      theme_minimal(base_size = 13) + theme(plot.background = element_rect(fill = "#1b1b23", colour = NA), panel.background = element_rect(fill = "#1b1b23", colour = NA), text = element_text(colour = "#e8e8ee"), axis.text = element_text(colour = "#c7c7d1"), axis.title = element_text(colour = "#c7c7d1"), panel.grid.major = element_line(colour = "#34343e"), panel.grid.minor = element_blank())
    ggplotly(p, tooltip = "text")
  })

  output$year_chart <- renderPlotly({
    d <- filtered() %>% filter(!is.na(release_year)) %>% count(release_year)
    p <- ggplot(d, aes(release_year, n, text = paste("Year:", release_year, "<br>Titles:", n))) +
      geom_line(linewidth = 1, colour = "#b20710") + geom_point(size = 2) +
      labs(x = "Release year", y = "Number of titles") + theme_minimal(base_size = 13) + theme(plot.background = element_rect(fill = "#1b1b23", colour = NA), panel.background = element_rect(fill = "#1b1b23", colour = NA), text = element_text(colour = "#e8e8ee"), axis.text = element_text(colour = "#c7c7d1"), axis.title = element_text(colour = "#c7c7d1"), panel.grid.major = element_line(colour = "#34343e"), panel.grid.minor = element_blank())
    ggplotly(p, tooltip = "text")
  })

  output$country_chart <- renderPlotly({
    d <- filtered() %>% filter(country != "Not available") %>%
      mutate(country = trimws(sub(",.*", "", country))) %>% count(country, sort = TRUE) %>% head(10)
    p <- ggplot(d, aes(reorder(country, n), n, text = paste(country, n))) +
      geom_col(fill = "#b20710") + coord_flip() +
      labs(x = NULL, y = "Number of titles") + theme_minimal(base_size = 13) + theme(plot.background = element_rect(fill = "#1b1b23", colour = NA), panel.background = element_rect(fill = "#1b1b23", colour = NA), text = element_text(colour = "#e8e8ee"), axis.text = element_text(colour = "#c7c7d1"), axis.title = element_text(colour = "#c7c7d1"), panel.grid.major = element_line(colour = "#34343e"), panel.grid.minor = element_blank())
    ggplotly(p, tooltip = "text")
  })

  output$rating_chart <- renderPlotly({
    d <- filtered() %>% count(rating, sort = TRUE) %>% head(12)
    p <- ggplot(d, aes(reorder(rating, n), n, text = paste(rating, n))) +
      geom_col(fill = "#555555") + coord_flip() +
      labs(x = NULL, y = "Number of titles") + theme_minimal(base_size = 13) + theme(plot.background = element_rect(fill = "#1b1b23", colour = NA), panel.background = element_rect(fill = "#1b1b23", colour = NA), text = element_text(colour = "#e8e8ee"), axis.text = element_text(colour = "#c7c7d1"), axis.title = element_text(colour = "#c7c7d1"), panel.grid.major = element_line(colour = "#34343e"), panel.grid.minor = element_blank())
    ggplotly(p, tooltip = "text")
  })

  output$genre_chart <- renderPlotly({
    d <- filtered() %>% filter(!is.na(listed_in)) %>%
      tidyr::separate_rows(listed_in, sep = ",") %>%
      mutate(listed_in = trimws(listed_in)) %>% count(listed_in, sort = TRUE) %>% head(15)
    p <- ggplot(d, aes(reorder(listed_in, n), n, text = paste(listed_in, n))) +
      geom_col(fill = "#b20710") + coord_flip() +
      labs(x = NULL, y = "Number of titles") + theme_minimal(base_size = 13) + theme(plot.background = element_rect(fill = "#1b1b23", colour = NA), panel.background = element_rect(fill = "#1b1b23", colour = NA), text = element_text(colour = "#e8e8ee"), axis.text = element_text(colour = "#c7c7d1"), axis.title = element_text(colour = "#c7c7d1"), panel.grid.major = element_line(colour = "#34343e"), panel.grid.minor = element_blank())
    ggplotly(p, tooltip = "text")
  })

  output$duration_chart <- renderPlotly({
    d <- filtered() %>% filter(type == "Movie", duration_unit == "Minutes", !is.na(duration_number))
    validate(need(nrow(d) > 0, "No movie duration data available for the selected filters."))
    p <- ggplot(d, aes(duration_number)) +
      geom_histogram(binwidth = 10, fill = "#b20710", colour = "white") +
      labs(x = "Duration (minutes)", y = "Number of movies") + theme_minimal(base_size = 13) + theme(plot.background = element_rect(fill = "#1b1b23", colour = NA), panel.background = element_rect(fill = "#1b1b23", colour = NA), text = element_text(colour = "#e8e8ee"), axis.text = element_text(colour = "#c7c7d1"), axis.title = element_text(colour = "#c7c7d1"), panel.grid.major = element_line(colour = "#34343e"), panel.grid.minor = element_blank())
    ggplotly(p)
  })

  output$added_chart <- renderPlotly({
    d <- filtered() %>% filter(!is.na(added_year)) %>% count(added_year)
    validate(need(nrow(d) > 0, "No date_added values available in the selected data."))
    p <- ggplot(d, aes(added_year, n, text = paste("Added year:", added_year, "<br>Titles:", n))) +
      geom_col(fill = "#b20710") + labs(x = "Year added", y = "Titles added") +
      theme_minimal(base_size = 13) + theme(plot.background = element_rect(fill = "#1b1b23", colour = NA), panel.background = element_rect(fill = "#1b1b23", colour = NA), text = element_text(colour = "#e8e8ee"), axis.text = element_text(colour = "#c7c7d1"), axis.title = element_text(colour = "#c7c7d1"), panel.grid.major = element_line(colour = "#34343e"), panel.grid.minor = element_blank())
    ggplotly(p, tooltip = "text")
  })

  output$titles_table <- renderDT({
    d <- filtered()
    q <- trimws(input$search_title)
    if (nzchar(q)) {
      d <- d %>% filter(grepl(q, paste(title, director, country, listed_in), ignore.case = TRUE))
    }
    d %>% select(type, title, director, country, release_year, rating, duration, listed_in) %>%
      datatable(filter = "top", rownames = FALSE,
                options = list(pageLength = 10, scrollX = TRUE, autoWidth = TRUE))
  })

  output$download_data <- downloadHandler(
    filename = function() paste0("netflix_filtered_titles_", Sys.Date(), ".csv"),
    content = function(file) write_csv(filtered(), file)
  )
}

shinyApp(ui, server)
