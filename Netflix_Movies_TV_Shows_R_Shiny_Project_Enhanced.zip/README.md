# Netflix Movies & TV Shows Analysis (R Shiny Mini Project)

## Project overview
An interactive dashboard for exploring Netflix movies and TV shows using R Shiny.

## Features
- KPI cards: total titles, movies, TV shows and countries
- Interactive charts: content type, release year, country, ratings, genres, movie duration and year added
- Filters: content type, country and release-year range
- Searchable title table
- Download filtered records as CSV
- Upload your own Netflix titles CSV
- Includes a small demonstration dataset so the app runs immediately

## Requirements
R (recommended R 4.2 or later) and the following packages:
`shiny`, `shinydashboard`, `dplyr`, `ggplot2`, `plotly`, `DT`, `readr`, `lubridate`, `tibble`, `tidyr`.

## Installation
Open RStudio, set the working directory to this project folder, then run:

```r
install.packages(c(
  "shiny", "shinydashboard", "dplyr", "ggplot2", "plotly",
  "DT", "readr", "lubridate", "tibble", "tidyr"
))
```

## Run the project
```r
shiny::runApp()
```
Or open `app.R` in RStudio and click **Run App**.

## Use a full dataset
The app starts with a small demo dataset. For full analysis:
1. Obtain a Netflix titles CSV from a reputable public dataset source (for example, the Netflix Movies and TV Shows dataset on Kaggle).
2. Check the dataset licence and cite the source in your academic report.
3. Upload the CSV using **Upload Netflix CSV** in the dashboard sidebar.

The standard dataset commonly includes columns such as `show_id`, `type`, `title`, `director`, `country`, `date_added`, `release_year`, `rating`, `duration`, and `listed_in`. The app requires `type`, `title`, and `release_year`; other columns are optional.

## Suggested mini-project report sections
1. Introduction
2. Problem statement
3. Objectives
4. Software and hardware requirements
5. Dataset description
6. Methodology and data preprocessing
7. Dashboard modules and screenshots
8. Results and observations
9. Conclusion
10. References

## Important academic note
The included demo rows are for testing the dashboard only. Do not present demo-data findings as actual Netflix catalogue statistics. Upload a properly sourced full dataset before preparing final results and screenshots.


## Interface update
The dashboard uses a modern dark theme inspired by streaming-platform interfaces, with a red accent, welcome banner, refined navigation, responsive spacing, styled KPI cards, and dark chart/table surfaces.
